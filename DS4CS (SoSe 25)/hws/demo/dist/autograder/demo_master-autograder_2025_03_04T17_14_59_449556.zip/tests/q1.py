OK_FORMAT = True

test = {   'name': 'q1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> def test_triangles(create_triangle):\n'
                                               "...     assert create_triangle(3, 5) == '*\\n**\\n***'\n"
                                               "...     assert create_triangle(6, 10) == '*\\n**\\n***\\n****\\n*****\\n******'\n"
                                               '...     try:\n'
                                               '...         create_triangle(3, 4)\n'
                                               '...     except ValueError as e:\n'
                                               "...         assert str(e) == 'Invalid right triangle dimensions'\n"
                                               '>>> test_triangles(create_triangle)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
